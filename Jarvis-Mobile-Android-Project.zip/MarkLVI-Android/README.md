# Mark LVI — Mobile (Android)

PC-র জার্ভিসের মোবাইল ভার্সন। Gemini Live দিয়ে কথা বলে, আর ফোনের সব কিছু কন্ট্রোল করার টুল ফোনের ভেতরেই চলে।

## APK বানানোর নিয়ম (একবারের কাজ, ~১০ মিনিট)

এই সেশনে Android SDK ডাউনলোড ব্লক ছিল, তাই APK এখানে বিল্ড করা যায়নি। GitHub-এর ফ্রি সার্ভার বিল্ড করে দেবে।

1. https://github.com এ ফ্রি অ্যাকাউন্ট খোলো, **New repository** দিয়ে একটা রিপোজিটরি বানাও (নাম: `jarvis-mobile`, Public বা Private দুটোই চলে)।
2. এই ZIP আনজিপ করো। রিপোজিটরিতে **Add file → Upload files** চাপো, আনজিপ করা ফোল্ডারের **ভেতরের সব ফাইল ও ফোল্ডার** (`app`, `.github`, `build.gradle`, `settings.gradle`, `gradle.properties`...) টেনে ছেড়ে দাও, তারপর **Commit changes**।
   - `.github` ফোল্ডার লুকানো থাকতে পারে। না দেখালে: রিপোজিটরিতে **Add file → Create new file**, নামের ঘরে `.github/workflows/build-apk.yml` লিখে এই ZIP-এর ভেতরের একই নামের ফাইলের লেখা পেস্ট করো।
3. **Actions** ট্যাবে যাও। "Build Jarvis APK" চলতে দেখবে (প্রথমবার ৪-৭ মিনিট)। সবুজ টিক এলে হয়ে গেছে।
4. রিপোজিটরির ডান পাশে **Releases** এ ক্লিক করো, সেখানে `Jarvis-MarkLVI-mobile.apk` — এটাই APK ডাউনলোড লিঙ্ক। ফোনে ডাউনলোড করে ইনস্টল করো (Install unknown apps অনুমতি দিতে হবে)।
5. লাল ❌ এলে ওই রানে ক্লিক করে এরর লগের শেষ ২০ লাইন আমাকে পাঠাও, ঠিক করে দেব।

## প্রথমবার চালানো

1. অ্যাপ খুলে সব অনুমতি (মাইক, কন্টাক্ট, কল, SMS, ক্যামেরা) দাও।
2. **SETTINGS** এ গিয়ে Gemini API key বসাও (ফ্রি: https://aistudio.google.com/apikey), **Test the key** চাপো।
3. একই পেজে নিচের অনুমতিগুলো একটা একটা করে অন করো (Android নিজে থেকে দিতে দেয় না):
   - **Accessibility control** (ট্যাপ, টাইপ, স্ক্রিন পড়া, স্ক্রিনশট, Back/Home)
   - **All files access** (ফাইল টুল)
   - **Display over other apps** (ব্যাকগ্রাউন্ড থেকে অ্যাপ খোলার জন্য জরুরি)
   - **Modify system settings** (ব্রাইটনেস), **Unrestricted battery**, **Exact alarms**
4. বড় **TALK** বাটন চাপো, কথা বলো। হেডফোন ছাড়া থাকলে Jarvis কথা বলার সময় মাইক বন্ধ থাকে (নিজের আওয়াজ শোনা ঠেকাতে)। হেডফোন থাকলে Settings থেকে "interrupt" অন করো।

## PC-র ফিচার → মোবাইলে কী হলো

| PC ফিচার | মোবাইলে |
|---|---|
| Gemini Live ভয়েস, ট্রান্সক্রিপশন, মেমরি, undo, prompt-এর সব নিয়ম | হুবহু একই (`assets/prompt.txt` মোবাইল অনুযায়ী) |
| হলোগ্রাফিক অবতার (PyQt) | Canvas দিয়ে আঁকা অর্ব HUD, আওয়াজে নড়ে |
| `open_app` | ফোনের ইনস্টল করা অ্যাপ খোলে |
| `computer_settings`, `computer_control` | `phone_settings` (ভলিউম, ব্রাইটনেস, টর্চ, মিডিয়া, DND, সিস্টেম প্যানেল) + `screen_control` (ট্যাপ, সোয়াইপ, টাইপ, স্ক্রিন পড়া, Back/Home/Recents, লক, স্ক্রিনশট) |
| `send_message` | SMS সরাসরি; WhatsApp/Telegram/Messenger/Signal/Instagram/Email অ্যাপ চালিয়ে |
| `reminder` | অ্যালার্ম + নোটিফিকেশন + কথা বলে জানায় |
| `weather_report`, `web_search`, `flight_finder`, `youtube_video`, `browser_control` | একই, ফোনের ব্রাউজার/YouTube/Maps দিয়ে |
| `file_controller`, `file_processor` | ফোনের স্টোরেজে (ডিলিট = ট্র্যাশ, undo চলে); PDF/DOCX/PPTX/XLSX/ছবি পড়ে |
| `screen_process` | স্ক্রিন বা ক্যামেরা (পেছনের/সামনের) দেখে |
| `system_status` | ব্যাটারি, RAM, স্টোরেজ, নেটওয়ার্ক, তাপমাত্রা |
| `manage_monitor` | দিনে একবার টপিক চেক করে নোটিফিকেশন দেয় |
| `code_helper` | কোড লিখে Documents/Jarvis এ সেভ করে |
| নতুন (শুধু ফোনে) | `make_call`, `find_contact`, `set_alarm_timer`, `navigate`, `clipboard`, `calendar_event`, `where_am_i`, `set_wallpaper` |

## যা মোবাইলে বানানো হয়নি (আর কারণ)

- `game_updater` (Steam), `dev_agent`, `desktop_control`, পিসি হটকি: ফোনে এর কোনো সমতুল্য নেই।
- `providers/` (লোকাল Whisper/Piper/Ollama ইঞ্জিন), ওয়েক-ওয়ার্ড ("Hey Jarvis"), `plugins/` ড্রপ-ইন লোডার: পাইথন-নির্ভর, ফোনে আলাদা করে বানাতে হবে। এখন ভয়েস শুধু Gemini Live দিয়ে চলে।
- Android নিজে থেকে Wi-Fi/Bluetooth/ডেটা সুইচ অন-অফ করতে দেয় না, তাই সেগুলোর সেটিংস প্যানেল খুলে দেয়।
- স্ক্রিনশট নিতে Android 11+ লাগবে; ক্যামেরা ক্যাপচারের সময় অ্যাপ স্ক্রিনে খোলা থাকতে হবে।
- WhatsApp/Telegram মেসেজ অ্যাপের স্ক্রিন চালিয়ে পাঠানো হয়, তাই "পৌঁছেছে কি না" নিশ্চিত করা যায় না। Jarvis সেটাই বলবে।
