package com.markvi.jarvis;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Bitmap;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Build;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.io.ByteArrayOutputStream;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/**
 * The phone's "hands": taps, swipes, typing, reading the screen, screenshots and system buttons.
 * Mobile replacement for pyautogui / pywinauto in the PC version. The user enables it once in
 * Settings > Accessibility.
 */
public class JarvisAccessibility extends AccessibilityService {

    private static volatile JarvisAccessibility inst;

    public static JarvisAccessibility get() {
        return inst;
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        inst = this;
        Bus.log("Accessibility service connected");
    }

    @Override
    public boolean onUnbind(android.content.Intent intent) {
        inst = null;
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        inst = null;
        super.onDestroy();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
    }

    @Override
    public void onInterrupt() {
    }

    // ------------------------------------------------------------------ basic actions

    public boolean global(int action) {
        return performGlobalAction(action);
    }

    public int[] screenSize() {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        return new int[]{dm.widthPixels, dm.heightPixels};
    }

    private boolean gesture(Path p, long durationMs) {
        GestureDescription.Builder b = new GestureDescription.Builder();
        b.addStroke(new GestureDescription.StrokeDescription(p, 0, Math.max(1, durationMs)));
        final CountDownLatch done = new CountDownLatch(1);
        final boolean[] ok = new boolean[1];
        boolean dispatched = dispatchGesture(b.build(), new GestureResultCallback() {
            @Override
            public void onCompleted(GestureDescription g) {
                ok[0] = true;
                done.countDown();
            }

            @Override
            public void onCancelled(GestureDescription g) {
                done.countDown();
            }
        }, null);
        if (!dispatched) return false;
        try {
            done.await(durationMs + 1500, TimeUnit.MILLISECONDS);
        } catch (InterruptedException ignored) {
        }
        return ok[0];
    }

    public boolean tap(float x, float y) {
        Path p = new Path();
        p.moveTo(x, y);
        return gesture(p, 60);
    }

    public boolean longPress(float x, float y) {
        Path p = new Path();
        p.moveTo(x, y);
        return gesture(p, 700);
    }

    public boolean swipe(float x1, float y1, float x2, float y2, long ms) {
        Path p = new Path();
        p.moveTo(x1, y1);
        p.lineTo(x2, y2);
        return gesture(p, ms);
    }

    /** direction = which way the CONTENT should move to reveal more: "down" shows later content. */
    public boolean scroll(boolean forward) {
        int[] s = screenSize();
        float x = s[0] / 2f;
        float top = s[1] * 0.30f;
        float bottom = s[1] * 0.72f;
        return forward ? swipe(x, bottom, x, top, 350) : swipe(x, top, x, bottom, 350);
    }

    // ------------------------------------------------------------------ reading and finding

    public String readScreen(int maxChars) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return "";
        StringBuilder sb = new StringBuilder();
        collect(root, sb, maxChars, 0);
        return sb.toString().trim();
    }

    private void collect(AccessibilityNodeInfo n, StringBuilder sb, int max, int depth) {
        if (n == null || sb.length() >= max || depth > 40) return;
        CharSequence t = n.getText();
        CharSequence d = n.getContentDescription();
        if (t != null && t.length() > 0) {
            sb.append(t);
            if (n.isClickable()) sb.append(" [button]");
            sb.append('\n');
        } else if (d != null && d.length() > 0) {
            sb.append('(').append(d).append(')');
            if (n.isClickable()) sb.append(" [button]");
            sb.append('\n');
        }
        for (int i = 0; i < n.getChildCount(); i++) collect(n.getChild(i), sb, max, depth + 1);
    }

    private AccessibilityNodeInfo findByLabel(AccessibilityNodeInfo n, String needle, boolean exact, int depth) {
        if (n == null || depth > 40) return null;
        CharSequence t = n.getText();
        CharSequence d = n.getContentDescription();
        if (matches(t, needle, exact) || matches(d, needle, exact)) return n;
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo r = findByLabel(n.getChild(i), needle, exact, depth + 1);
            if (r != null) return r;
        }
        return null;
    }

    private static boolean matches(CharSequence cs, String needle, boolean exact) {
        if (cs == null) return false;
        String s = cs.toString().trim().toLowerCase();
        String q = needle.trim().toLowerCase();
        if (s.isEmpty() || q.isEmpty()) return false;
        return exact ? s.equals(q) : s.contains(q);
    }

    private boolean clickNode(AccessibilityNodeInfo n) {
        AccessibilityNodeInfo cur = n;
        for (int i = 0; i < 8 && cur != null; i++) {
            if (cur.isClickable() && cur.isEnabled()) {
                if (cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true;
            }
            cur = cur.getParent();
        }
        Rect r = new Rect();
        n.getBoundsInScreen(r);
        if (r.width() > 0 && r.height() > 0) return tap(r.centerX(), r.centerY());
        return false;
    }

    public boolean clickText(String text) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return false;
        AccessibilityNodeInfo n = findByLabel(root, text, true, 0);
        if (n == null) n = findByLabel(root, text, false, 0);
        return n != null && clickNode(n);
    }

    public boolean hasText(String text) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        return root != null && findByLabel(root, text, false, 0) != null;
    }

    public boolean typeText(String text, boolean append) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return false;
        AccessibilityNodeInfo f = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
        if (f == null) f = firstEditable(root, 0);
        if (f == null) return false;
        String base = "";
        if (append && f.getText() != null && !f.isShowingHintText()) base = f.getText().toString();
        Bundle b = new Bundle();
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, base + text);
        return f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b);
    }

    private AccessibilityNodeInfo firstEditable(AccessibilityNodeInfo n, int depth) {
        if (n == null || depth > 40) return null;
        if (n.isEditable()) return n;
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo r = firstEditable(n.getChild(i), depth + 1);
            if (r != null) return r;
        }
        return null;
    }

    // ------------------------------------------------------------------ screenshot

    /** JPEG of the current screen, scaled to at most 1024 px on the long side; null when unavailable. */
    public byte[] screenshotJpeg() {
        if (Build.VERSION.SDK_INT < 30) return null;
        final CountDownLatch done = new CountDownLatch(1);
        final Bitmap[] out = new Bitmap[1];
        takeScreenshot(Display.DEFAULT_DISPLAY, getMainExecutor(), new TakeScreenshotCallback() {
            @Override
            public void onSuccess(ScreenshotResult result) {
                try {
                    Bitmap hw = Bitmap.wrapHardwareBuffer(result.getHardwareBuffer(), result.getColorSpace());
                    if (hw != null) out[0] = hw.copy(Bitmap.Config.ARGB_8888, false);
                    result.getHardwareBuffer().close();
                } catch (Exception ignored) {
                }
                done.countDown();
            }

            @Override
            public void onFailure(int errorCode) {
                done.countDown();
            }
        });
        try {
            done.await(5, TimeUnit.SECONDS);
        } catch (InterruptedException ignored) {
        }
        Bitmap b = out[0];
        if (b == null) return null;
        return toJpeg(b, 1024);
    }

    public static byte[] toJpeg(Bitmap b, int maxSide) {
        int w = b.getWidth();
        int h = b.getHeight();
        float k = Math.min(1f, maxSide / (float) Math.max(w, h));
        Bitmap s = k < 1f ? Bitmap.createScaledBitmap(b, Math.round(w * k), Math.round(h * k), true) : b;
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        s.compress(Bitmap.CompressFormat.JPEG, 72, bo);
        return bo.toByteArray();
    }

    // ------------------------------------------------------------------ helpers for messaging

    private static final String[] SEND_LABELS = {"send", "পাঠান", "भेजें", "enviar", "gönder", "envoyer"};

    /** Waits for a Send button to appear and presses it. */
    public static boolean autoPressSend(long timeoutMs) {
        long end = System.currentTimeMillis() + timeoutMs;
        try {
            Thread.sleep(1500);
        } catch (InterruptedException ignored) {
        }
        while (System.currentTimeMillis() < end) {
            JarvisAccessibility s = inst;
            if (s == null) return false;
            AccessibilityNodeInfo root = s.getRootInActiveWindow();
            if (root != null) {
                for (String label : SEND_LABELS) {
                    AccessibilityNodeInfo n = s.findByLabel(root, label, true, 0);
                    if (n != null && s.clickNode(n)) return true;
                }
            }
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                return false;
            }
        }
        return false;
    }

    /** Waits for text to appear on screen and taps it. */
    public static boolean tapTextWithin(String text, long timeoutMs) {
        long end = System.currentTimeMillis() + timeoutMs;
        while (System.currentTimeMillis() < end) {
            JarvisAccessibility s = inst;
            if (s == null) return false;
            if (s.hasText(text) && s.clickText(text)) return true;
            try {
                Thread.sleep(600);
            } catch (InterruptedException e) {
                return false;
            }
        }
        return false;
    }
}
