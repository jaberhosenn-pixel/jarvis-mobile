package com.markvi.jarvis;

import android.app.ActivityManager;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Environment;
import android.os.PowerManager;
import android.os.StatFs;
import android.os.SystemClock;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import static com.markvi.jarvis.Tools.reg;
import static com.markvi.jarvis.Tools.schema;

/** Core tools: status, memory, reminders, weather, search, code, video, flights, browser, monitors. */
public final class ToolsCore {
    private ToolsCore() {}

    static void register() {
        reg("system_status",
                "Returns real-time phone metrics: battery level and charging, temperature, RAM, storage, network type, uptime. "
                        + "Use when the user asks about battery, performance, storage, heat or connection.",
                schema(""),
                (c, a) -> systemStatus(c));

        reg("save_memory",
                "Save an important personal fact about the user to long-term memory. Call this silently whenever the user "
                        + "reveals something worth remembering: name, city, job, preferences, relationships, projects, plans. "
                        + "Do NOT announce that you are saving. Values must be in English.",
                schema("category,key,value",
                        "category:STRING:identity | preferences | projects | relationships | wishes | notes",
                        "key:STRING:short snake_case key, e.g. name, favorite_food",
                        "value:STRING:concise value in English"),
                (c, a) -> {
                    Memory.save(c, a.optString("category", "notes"), a.optString("key", "note"), a.optString("value"));
                    return J.ok();
                });

        reg("recall_memory",
                "Look up a fact stored about the user that is NOT in the memory block of your prompt (see [ALSO REMEMBERED]). "
                        + "Also call it before saying you do not know something personal. Leave query empty for everything.",
                schema("", "query:STRING:keyword, name or category; empty lists everything"),
                (c, a) -> {
                    String r = Memory.recall(c, a.optString("query", ""));
                    return J.ok("memory", r.isEmpty() ? "(nothing found)" : r);
                });

        reg("undo",
                "Reverse the last change YOU made on this phone: a file you moved, renamed, created, or deleted, or a volume or "
                        + "brightness change. Call when the user says undo, revert, take it back. Use action='list' to see what can be undone.",
                schema("", "action:STRING:undo (default) | list"),
                (c, a) -> {
                    if ("list".equalsIgnoreCase(a.optString("action"))) {
                        return J.ok("undoable", Util.undoList());
                    }
                    String r = Util.undoLast();
                    return r == null ? J.fail("nothing to undo") : J.ok("undone", r);
                });

        reg("shutdown_jarvis",
                "Ends the voice session and stops listening. Call only when the user explicitly says goodbye, stop, or close Jarvis, in any language.",
                schema(""),
                (c, a) -> {
                    JarvisService s = JarvisService.get();
                    if (s != null) s.stopSessionSoon();
                    return J.ok("note", "session ending; say a very short goodbye");
                });

        reg("reminder",
                "Sets a timed reminder that fires a notification and a spoken alert at the given date and time.",
                schema("date,time,message",
                        "date:STRING:YYYY-MM-DD",
                        "time:STRING:HH:MM, 24-hour",
                        "message:STRING:reminder text"),
                (c, a) -> setReminder(c, a));

        reg("weather_report",
                "Gives the current weather and a 3-day forecast for a city.",
                schema("city", "city:STRING:city name"),
                (c, a) -> weather(a.optString("city")));

        reg("web_search",
                "Searches the web. Use for ANY question about current facts, events, prices or topics; prefer this over guessing. "
                        + "Modes: search (default), news, research (deep answer), price, compare.",
                schema("query",
                        "query:STRING:search query or topic",
                        "mode:STRING:search | news | research | price | compare",
                        "items:STRING:comma-separated items to compare (compare mode)",
                        "aspect:STRING:price | specs | reviews | features"),
                (c, a) -> webSearch(c, a));

        reg("browser_control",
                "Opens web pages on the phone. Actions: open_url (url), search (query; Google), read_page (url; fetches the page text for you "
                        + "to summarise), maps_search (query).",
                schema("action",
                        "action:STRING:open_url | search | read_page | maps_search",
                        "url:STRING:web address",
                        "query:STRING:search words"),
                (c, a) -> browser(c, a));

        reg("youtube_video",
                "YouTube: action 'play' or 'search' opens YouTube results for the query in the YouTube app; 'open' opens a given URL; "
                        + "'summarize' watches a YouTube URL (or finds one for the query) and returns a summary.",
                schema("action",
                        "action:STRING:play | search | open | summarize",
                        "query:STRING:what to look for",
                        "url:STRING:YouTube URL"),
                (c, a) -> youtube(c, a));

        reg("flight_finder",
                "Looks up flights between two places on a date: opens Google Flights and returns a researched summary of typical prices and options.",
                schema("origin,destination",
                        "origin:STRING:departure city or airport",
                        "destination:STRING:arrival city or airport",
                        "date:STRING:YYYY-MM-DD or natural language",
                        "return_date:STRING:optional return date"),
                (c, a) -> flights(c, a));

        reg("code_helper",
                "Writes, explains or fixes code. Actions: write (description, language, optional filename: the file is saved to Documents/Jarvis), "
                        + "explain (code), fix (code + description of the problem). Returns the result for you to summarise briefly aloud.",
                schema("action",
                        "action:STRING:write | explain | fix",
                        "description:STRING:what the code should do or what is wrong",
                        "language:STRING:programming language",
                        "code:STRING:existing code for explain/fix",
                        "filename:STRING:file name to save to (write)"),
                (c, a) -> code(c, a));

        reg("manage_monitor",
                "Add, remove or list background topics. Once a day the phone checks each topic and notifies the user of new developments. "
                        + "Do NOT add crypto, financial or trading topics.",
                schema("action",
                        "action:STRING:add | remove | list",
                        "topic:STRING:topic to monitor"),
                (c, a) -> monitor(c, a));
    }

    // ------------------------------------------------------------------ status

    private static JSONObject systemStatus(Context c) {
        JSONObject o = J.ok();
        Intent b = c.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (b != null) {
            int level = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = b.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
            int st = b.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
            int temp = b.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0);
            J.put(o, "battery_percent", scale > 0 ? level * 100 / scale : level);
            J.put(o, "charging", st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL);
            J.put(o, "battery_temp_c", temp / 10.0);
        }
        ActivityManager am = (ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(mi);
        J.put(o, "ram_total_mb", mi.totalMem / 1048576L);
        J.put(o, "ram_free_mb", mi.availMem / 1048576L);
        try {
            StatFs fs = new StatFs(Environment.getDataDirectory().getPath());
            J.put(o, "storage_total_gb", Math.round(fs.getTotalBytes() / 1.0e8) / 10.0);
            J.put(o, "storage_free_gb", Math.round(fs.getAvailableBytes() / 1.0e8) / 10.0);
        } catch (Exception ignored) {
        }
        J.put(o, "uptime_hours", Math.round(SystemClock.elapsedRealtime() / 360000.0) / 10.0);
        J.put(o, "network", networkType(c));
        if (Build.VERSION.SDK_INT >= 29) {
            PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
            J.put(o, "thermal_status", pm.getCurrentThermalStatus());
            J.put(o, "power_saver", pm.isPowerSaveMode());
        }
        J.put(o, "device", Build.MANUFACTURER + " " + Build.MODEL);
        return o;
    }

    private static String networkType(Context c) {
        try {
            ConnectivityManager cm = (ConnectivityManager) c.getSystemService(Context.CONNECTIVITY_SERVICE);
            Network n = cm.getActiveNetwork();
            if (n == null) return "offline";
            NetworkCapabilities nc = cm.getNetworkCapabilities(n);
            if (nc == null) return "unknown";
            if (nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) return "wifi";
            if (nc.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) return "mobile data";
            if (nc.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) return "ethernet";
            return "other";
        } catch (Exception e) {
            return "unknown";
        }
    }

    // ------------------------------------------------------------------ reminders

    private static JSONObject setReminder(Context c, JSONObject a) throws Exception {
        String d = a.optString("date").trim();
        String t = a.optString("time").trim();
        String msg = a.optString("message").trim();
        if (msg.isEmpty()) return J.fail("message is empty");
        Date when = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).parse(d + " " + t);
        if (when == null) return J.fail("could not read date/time");
        if (when.getTime() < System.currentTimeMillis() - 60000) return J.fail("that time is in the past");

        JSONArray list = J.parse("{\"r\":" + Prefs.sp(c).getString("reminders", "[]") + "}").optJSONArray("r");
        if (list == null) list = new JSONArray();
        int id = (int) (System.currentTimeMillis() % 1000000000L);
        list.put(J.obj("id", id, "when", when.getTime(), "msg", msg));
        Prefs.sp(c).edit().putString("reminders", list.toString()).apply();
        scheduleReminder(c, id, when.getTime(), msg);
        return J.ok("scheduled_for", d + " " + t, "message", msg);
    }

    public static void scheduleReminder(Context c, int id, long whenMs, String msg) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        Intent i = new Intent(c, ReminderReceiver.class).putExtra("id", id).putExtra("msg", msg);
        PendingIntent pi = PendingIntent.getBroadcast(c, id, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        try {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenMs, pi);
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenMs, pi);
            }
        } catch (SecurityException e) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenMs, pi);
        }
    }

    /** Re-arms every future reminder (after a reboot) and drops the ones already past. */
    public static void rescheduleAll(Context c) {
        JSONArray list = J.parse("{\"r\":" + Prefs.sp(c).getString("reminders", "[]") + "}").optJSONArray("r");
        if (list == null) return;
        JSONArray keep = new JSONArray();
        long now = System.currentTimeMillis();
        for (int i = 0; i < list.length(); i++) {
            JSONObject r = list.optJSONObject(i);
            if (r == null) continue;
            if (r.optLong("when") > now) {
                keep.put(r);
                scheduleReminder(c, r.optInt("id"), r.optLong("when"), r.optString("msg"));
            }
        }
        Prefs.sp(c).edit().putString("reminders", keep.toString()).apply();
        scheduleMonitor(c);
    }

    // ------------------------------------------------------------------ weather

    private static String wmo(int code) {
        switch (code) {
            case 0: return "clear sky";
            case 1: return "mostly clear";
            case 2: return "partly cloudy";
            case 3: return "overcast";
            case 45: case 48: return "fog";
            case 51: case 53: case 55: return "drizzle";
            case 61: return "light rain";
            case 63: return "rain";
            case 65: return "heavy rain";
            case 71: case 73: case 75: return "snow";
            case 80: case 81: case 82: return "rain showers";
            case 95: case 96: case 99: return "thunderstorm";
            default: return "weather code " + code;
        }
    }

    private static JSONObject weather(String city) throws Exception {
        if (city == null || city.trim().isEmpty()) return J.fail("city is empty");
        JSONObject g = J.parse(GeminiRest.httpGet("https://geocoding-api.open-meteo.com/v1/search?count=1&name="
                + URLEncoder.encode(city.trim(), "UTF-8")));
        JSONArray res = g.optJSONArray("results");
        if (res == null || res.length() == 0) return J.fail("city not found: " + city);
        JSONObject p = res.getJSONObject(0);
        String url = "https://api.open-meteo.com/v1/forecast?latitude=" + p.optDouble("latitude")
                + "&longitude=" + p.optDouble("longitude")
                + "&current=temperature_2m,apparent_temperature,relative_humidity_2m,wind_speed_10m,weather_code"
                + "&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max,weather_code"
                + "&timezone=auto&forecast_days=3";
        JSONObject f = J.parse(GeminiRest.httpGet(url));
        JSONObject cur = f.optJSONObject("current");
        JSONObject out = J.ok("place", p.optString("name") + ", " + p.optString("country"));
        if (cur != null) {
            J.put(out, "now", J.obj(
                    "temp_c", cur.optDouble("temperature_2m"),
                    "feels_like_c", cur.optDouble("apparent_temperature"),
                    "humidity_pct", cur.optDouble("relative_humidity_2m"),
                    "wind_kmh", cur.optDouble("wind_speed_10m"),
                    "sky", wmo(cur.optInt("weather_code"))));
        }
        JSONObject d = f.optJSONObject("daily");
        if (d != null) {
            JSONArray days = new JSONArray();
            JSONArray dt = d.optJSONArray("time");
            for (int i = 0; dt != null && i < dt.length(); i++) {
                days.put(J.obj("date", dt.optString(i),
                        "max_c", d.optJSONArray("temperature_2m_max").optDouble(i),
                        "min_c", d.optJSONArray("temperature_2m_min").optDouble(i),
                        "rain_chance_pct", d.optJSONArray("precipitation_probability_max").optDouble(i),
                        "sky", wmo(d.optJSONArray("weather_code").optInt(i))));
            }
            J.put(out, "forecast", days);
        }
        return out;
    }

    // ------------------------------------------------------------------ search / browser

    private static JSONObject webSearch(Context c, JSONObject a) throws Exception {
        String q = a.optString("query").trim();
        String mode = a.optString("mode", "search").toLowerCase(Locale.ROOT);
        String prompt;
        switch (mode) {
            case "news":
                prompt = "Give the latest headlines and key facts on: " + q + ". Be concise, with dates.";
                break;
            case "research":
                prompt = "Research this thoroughly and give a comprehensive but compact answer with the key facts and numbers: " + q;
                break;
            case "price":
                prompt = "Find the current price of: " + q + ". Give the price range, where it is sold, and the date of the data.";
                break;
            case "compare":
                prompt = "Compare these items side by side on " + a.optString("aspect", "key aspects") + ": "
                        + a.optString("items", q) + ". Be concise.";
                break;
            default:
                prompt = "Answer using current web information, concisely: " + q;
        }
        String text = GeminiRest.generate(c, prompt, true, null, null);
        return J.ok("result", J.untrusted("web", text));
    }

    private static JSONObject browser(Context c, JSONObject a) throws Exception {
        String act = a.optString("action", "open_url").toLowerCase(Locale.ROOT);
        switch (act) {
            case "search": {
                String q = a.optString("query");
                Util.launch(c, new Intent(Intent.ACTION_VIEW,
                        Uri.parse("https://www.google.com/search?q=" + URLEncoder.encode(q, "UTF-8"))));
                return J.started("opened", "Google search: " + q);
            }
            case "maps_search": {
                String q = a.optString("query");
                Util.launch(c, new Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + URLEncoder.encode(q, "UTF-8"))));
                return J.started("opened", "Maps: " + q);
            }
            case "read_page": {
                String url = fixUrl(a.optString("url"));
                String html = GeminiRest.httpGet(url);
                String text = html.replaceAll("(?is)<(script|style|noscript)[^>]*>.*?</\\1>", " ")
                        .replaceAll("(?s)<[^>]+>", " ")
                        .replaceAll("&nbsp;", " ").replaceAll("&amp;", "&")
                        .replaceAll("\\s+", " ").trim();
                if (text.length() > 6000) text = text.substring(0, 6000);
                return J.ok("page", J.untrusted(url, text));
            }
            default: {
                String url = fixUrl(a.optString("url"));
                Util.launch(c, new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                return J.started("opened", url);
            }
        }
    }

    private static String fixUrl(String u) {
        u = u == null ? "" : u.trim();
        if (u.isEmpty()) return "https://www.google.com";
        if (!u.startsWith("http://") && !u.startsWith("https://")) u = "https://" + u;
        return u;
    }

    private static JSONObject youtube(Context c, JSONObject a) throws Exception {
        String act = a.optString("action", "search").toLowerCase(Locale.ROOT);
        String q = a.optString("query");
        String url = a.optString("url");
        if (act.equals("summarize")) {
            if (url.isEmpty()) {
                String found = GeminiRest.generate(c, "Give ONE full YouTube watch URL (https://www.youtube.com/watch?v=...) "
                        + "for: " + q + ". Output only the URL.", true, null, null);
                int i = found.indexOf("http");
                url = i >= 0 ? found.substring(i).split("\\s")[0] : "";
            }
            if (url.isEmpty()) return J.fail("no video found");
            String s = GeminiRest.generate(c, "Summarise this video in under 150 words: the main points only.", false, null, url);
            return J.ok("url", url, "summary", J.untrusted("youtube", s));
        }
        Uri u;
        if (act.equals("open") && !url.isEmpty()) {
            u = Uri.parse(fixUrl(url));
        } else {
            u = Uri.parse("https://www.youtube.com/results?search_query=" + URLEncoder.encode(q, "UTF-8"));
        }
        Util.launch(c, new Intent(Intent.ACTION_VIEW, u));
        return J.started("opened", u.toString());
    }

    private static JSONObject flights(Context c, JSONObject a) throws Exception {
        String o = a.optString("origin");
        String d = a.optString("destination");
        String date = a.optString("date");
        String ret = a.optString("return_date");
        String q = "Flights from " + o + " to " + d + (date.isEmpty() ? "" : " on " + date)
                + (ret.isEmpty() ? "" : " returning " + ret);
        Util.launch(c, new Intent(Intent.ACTION_VIEW,
                Uri.parse("https://www.google.com/travel/flights?q=" + URLEncoder.encode(q, "UTF-8"))));
        String s = GeminiRest.generate(c, q + ". Summarise typical prices, airlines and duration, and the cheapest "
                + "approach. Say clearly that prices are estimates. Be concise.", true, null, null);
        return J.ok("opened", "Google Flights", "summary", J.untrusted("web", s));
    }

    private static JSONObject code(Context c, JSONObject a) throws Exception {
        String act = a.optString("action", "write").toLowerCase(Locale.ROOT);
        String lang = a.optString("language", "python");
        String desc = a.optString("description");
        String code = a.optString("code");
        if (act.equals("explain")) {
            return J.ok("explanation", GeminiRest.generate(c, "Explain this code briefly and clearly:\n" + code));
        }
        String prompt = act.equals("fix")
                ? "Fix this " + lang + " code. Problem: " + desc + "\nReturn ONLY the corrected full code, no markdown fences.\n" + code
                : "Write " + lang + " code that does: " + desc + "\nReturn ONLY the code, no markdown fences, no commentary.";
        String out = GeminiRest.generate(c, prompt).replaceAll("(?s)^```[a-zA-Z]*\\n?", "").replaceAll("```\\s*$", "").trim();
        String name = a.optString("filename");
        if (name.isEmpty()) name = "jarvis_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date())
                + extFor(lang);
        File dir = ToolsFiles.jarvisDir(c);
        File f = new File(dir, new File(name).getName());
        try (FileOutputStream fo = new FileOutputStream(f)) {
            fo.write(out.getBytes("UTF-8"));
        }
        return J.ok("saved_to", f.getAbsolutePath(), "lines", out.split("\n").length,
                "preview", out.length() > 600 ? out.substring(0, 600) : out);
    }

    private static String extFor(String lang) {
        String l = lang.toLowerCase(Locale.ROOT);
        if (l.startsWith("py")) return ".py";
        if (l.equals("javascript") || l.equals("js")) return ".js";
        if (l.equals("java")) return ".java";
        if (l.equals("kotlin")) return ".kt";
        if (l.equals("html")) return ".html";
        if (l.equals("c++") || l.equals("cpp")) return ".cpp";
        if (l.equals("c")) return ".c";
        if (l.startsWith("bash") || l.equals("shell") || l.equals("sh")) return ".sh";
        return ".txt";
    }

    // ------------------------------------------------------------------ monitors

    private static JSONArray topics(Context c) {
        JSONArray a = J.parse("{\"t\":" + Prefs.sp(c).getString("topics", "[]") + "}").optJSONArray("t");
        return a == null ? new JSONArray() : a;
    }

    public static JSONArray monitorTopics(Context c) {
        return topics(c);
    }

    private static JSONObject monitor(Context c, JSONObject a) {
        String act = a.optString("action", "list").toLowerCase(Locale.ROOT);
        String topic = a.optString("topic").trim();
        JSONArray t = topics(c);
        if (act.equals("list")) return J.ok("topics", t);
        if (topic.isEmpty()) return J.fail("topic is empty");
        JSONArray n = new JSONArray();
        boolean found = false;
        for (int i = 0; i < t.length(); i++) {
            if (t.optString(i).equalsIgnoreCase(topic)) found = true;
            else n.put(t.optString(i));
        }
        if (act.equals("add")) {
            if (found) return J.ok("note", "already monitored");
            n = rebuildWith(t, topic);
        } else if (act.equals("remove")) {
            if (!found) return J.fail("not monitored: " + topic);
        } else {
            return J.fail("unknown action");
        }
        Prefs.sp(c).edit().putString("topics", n.toString()).apply();
        scheduleMonitor(c);
        return J.ok("topics", n);
    }

    private static JSONArray rebuildWith(JSONArray old, String add) {
        JSONArray n = new JSONArray();
        for (int i = 0; i < old.length(); i++) n.put(old.optString(i));
        n.put(add);
        return n;
    }

    public static void scheduleMonitor(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        PendingIntent pi = PendingIntent.getBroadcast(c, 7777, new Intent(c, MonitorReceiver.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        if (topics(c).length() == 0) {
            am.cancel(pi);
            return;
        }
        am.setInexactRepeating(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + AlarmManager.INTERVAL_HOUR,
                AlarmManager.INTERVAL_DAY, pi);
    }
}
