package com.markvi.jarvis;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/** The HUD screen: orb, transcript, typed input, mic button. */
public class MainActivity extends Activity implements Bus.Ui {

    private final Handler ui = new Handler(Looper.getMainLooper());
    private JarvisView hud;
    private TextView transcript;
    private ScrollView scroll;
    private Button mic;
    private Button muteBtn;
    private TextView logView;
    private ImageView preview;
    private TextView previewLabel;
    private EditText input;

    private final List<String> lines = new ArrayList<>();
    private String liveUser = "";
    private String liveAsst = "";
    private final StringBuilder logBuf = new StringBuilder();

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        buildUi();
        requestAllPermissions();
        handleIntent(getIntent());
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        setIntent(i);
        handleIntent(i);
    }

    private void handleIntent(Intent i) {
        if (i != null && Intent.ACTION_ASSIST.equals(i.getAction()) && !isRunning()) {
            ui.postDelayed(this::toggleSession, 400);
        }
    }

    private void buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        hud = new JarvisView(this);
        root.addView(hud, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(14), dp(10), dp(14), dp(12));
        root.addView(col, new FrameLayout.LayoutParams(-1, -1));

        // top bar
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = new TextView(this);
        title.setText("MARK LVI  /  MOBILE");
        title.setTextColor(Color.parseColor("#00E5FF"));
        title.setTextSize(13);
        title.setLetterSpacing(0.25f);
        top.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        Button gear = flatButton("SETTINGS");
        gear.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
        top.addView(gear);
        col.addView(top, new LinearLayout.LayoutParams(-1, -2));

        // spacer where the orb lives
        View spacer = new View(this);
        col.addView(spacer, new LinearLayout.LayoutParams(-1, 0, 1f));

        // image preview (camera / screen capture)
        previewLabel = new TextView(this);
        previewLabel.setTextColor(Color.parseColor("#80DEEA"));
        previewLabel.setTextSize(11);
        previewLabel.setVisibility(View.GONE);
        col.addView(previewLabel, new LinearLayout.LayoutParams(-2, -2));
        preview = new ImageView(this);
        preview.setAdjustViewBounds(true);
        preview.setScaleType(ImageView.ScaleType.FIT_CENTER);
        preview.setVisibility(View.GONE);
        preview.setOnClickListener(v -> {
            preview.setVisibility(View.GONE);
            previewLabel.setVisibility(View.GONE);
        });
        col.addView(preview, new LinearLayout.LayoutParams(dp(150), dp(150)));

        // transcript
        scroll = new ScrollView(this);
        transcript = new TextView(this);
        transcript.setTextColor(Color.parseColor("#CFEFF5"));
        transcript.setTextSize(15);
        transcript.setLineSpacing(0, 1.15f);
        transcript.setPadding(dp(12), dp(8), dp(12), dp(8));
        scroll.addView(transcript);
        GradientDrawable tbg = new GradientDrawable();
        tbg.setColor(Color.parseColor("#B0050E18"));
        tbg.setStroke(dp(1), Color.parseColor("#2200E5FF"));
        tbg.setCornerRadius(dp(14));
        scroll.setBackground(tbg);
        col.addView(scroll, new LinearLayout.LayoutParams(-1, dp(190)));

        logView = new TextView(this);
        logView.setTextColor(Color.parseColor("#5A8E99"));
        logView.setTextSize(10);
        logView.setMaxLines(2);
        logView.setPadding(dp(4), dp(4), dp(4), 0);
        col.addView(logView, new LinearLayout.LayoutParams(-1, -2));

        // typed input
        LinearLayout inRow = new LinearLayout(this);
        inRow.setOrientation(LinearLayout.HORIZONTAL);
        inRow.setGravity(Gravity.CENTER_VERTICAL);
        input = new EditText(this);
        input.setHint("Type to " + Prefs.assistantName(this) + "...");
        input.setHintTextColor(Color.parseColor("#557078"));
        input.setTextColor(Color.WHITE);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        input.setImeOptions(EditorInfo.IME_ACTION_SEND);
        input.setSingleLine(true);
        input.setOnEditorActionListener((v, id, e) -> {
            sendTyped();
            return true;
        });
        inRow.addView(input, new LinearLayout.LayoutParams(0, -2, 1f));
        Button send = flatButton("SEND");
        send.setOnClickListener(v -> sendTyped());
        inRow.addView(send);
        col.addView(inRow, new LinearLayout.LayoutParams(-1, -2));

        // controls
        LinearLayout ctl = new LinearLayout(this);
        ctl.setOrientation(LinearLayout.HORIZONTAL);
        ctl.setGravity(Gravity.CENTER);
        muteBtn = flatButton("MUTE");
        muteBtn.setOnClickListener(v -> {
            JarvisService s = JarvisService.get();
            if (s == null) return;
            s.setMuted(!s.isMuted());
            muteBtn.setText(s.isMuted() ? "UNMUTE" : "MUTE");
        });
        ctl.addView(muteBtn, new LinearLayout.LayoutParams(0, -2, 1f));

        mic = new Button(this);
        mic.setTextColor(Color.BLACK);
        mic.setTextSize(13);
        mic.setTypeface(null, android.graphics.Typeface.BOLD);
        GradientDrawable mbg = new GradientDrawable();
        mbg.setShape(GradientDrawable.OVAL);
        mbg.setColor(Color.parseColor("#00E5FF"));
        mic.setBackground(mbg);
        mic.setOnClickListener(v -> toggleSession());
        ctl.addView(mic, new LinearLayout.LayoutParams(dp(88), dp(88)));

        Button clear = flatButton("CLEAR");
        clear.setOnClickListener(v -> {
            lines.clear();
            liveUser = "";
            liveAsst = "";
            logBuf.setLength(0);
            logView.setText("");
            renderTranscript();
        });
        ctl.addView(clear, new LinearLayout.LayoutParams(0, -2, 1f));
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(-1, -2);
        clp.topMargin = dp(8);
        col.addView(ctl, clp);

        root.setOnApplyWindowInsetsListener((v, ins) -> {
            v.setPadding(0, ins.getSystemWindowInsetTop(), 0, ins.getSystemWindowInsetBottom());
            return ins;
        });
        setContentView(root);
        updateMic();
    }

    private Button flatButton(String label) {
        Button bt = new Button(this);
        bt.setText(label);
        bt.setTextSize(11);
        bt.setAllCaps(false);
        bt.setTextColor(Color.parseColor("#00E5FF"));
        bt.setBackgroundColor(Color.TRANSPARENT);
        bt.setLetterSpacing(0.15f);
        return bt;
    }

    // ------------------------------------------------------------------ session

    private boolean isRunning() {
        String s = Bus.lastState;
        return JarvisService.get() != null && !"IDLE".equals(s) && !"ERROR".equals(s);
    }

    private void toggleSession() {
        if (isRunning()) {
            startService(new Intent(this, JarvisService.class).setAction(JarvisService.ACTION_STOP));
            return;
        }
        if (Prefs.apiKey(this).isEmpty()) {
            Toast.makeText(this, "Add your Gemini API key first", Toast.LENGTH_LONG).show();
            startActivity(new Intent(this, SettingsActivity.class));
            return;
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Microphone permission is required", Toast.LENGTH_LONG).show();
            requestAllPermissions();
            return;
        }
        Intent i = new Intent(this, JarvisService.class).setAction(JarvisService.ACTION_START);
        startForegroundService(i);
        Bus.state("CONNECTING");
    }

    private void sendTyped() {
        String t = input.getText().toString().trim();
        if (t.isEmpty()) return;
        input.setText("");
        JarvisService s = JarvisService.get();
        if (s == null || !s.isLive()) {
            Toast.makeText(this, "Start the session first (tap the big button)", Toast.LENGTH_SHORT).show();
            return;
        }
        lines.add("YOU: " + t);
        renderTranscript();
        s.sendText(t);
    }

    private void requestAllPermissions() {
        List<String> need = new ArrayList<>();
        String[] wanted = {
                Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA, Manifest.permission.READ_CONTACTS,
                Manifest.permission.CALL_PHONE, Manifest.permission.SEND_SMS, Manifest.permission.ACCESS_COARSE_LOCATION
        };
        for (String p : wanted) {
            if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) need.add(p);
        }
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.POST_NOTIFICATIONS);
        }
        if (!need.isEmpty()) requestPermissions(need.toArray(new String[0]), 11);
    }

    // ------------------------------------------------------------------ lifecycle

    @Override
    protected void onStart() {
        super.onStart();
        Bus.ui = this;
        updateMic();
        hud.setState(Bus.lastState);
        if (Prefs.apiKey(this).isEmpty()) {
            addLine("Welcome. Open SETTINGS and paste your free Gemini API key (aistudio.google.com/apikey), then tap the big button.");
        }
    }

    @Override
    protected void onStop() {
        if (Bus.ui == this) Bus.ui = null;
        super.onStop();
    }

    private void addLine(String s) {
        if (!lines.contains(s)) {
            lines.add(s);
            renderTranscript();
        }
    }

    private void updateMic() {
        boolean run = isRunning();
        mic.setText(run ? "STOP" : "TALK");
        muteBtn.setText(JarvisService.get() != null && JarvisService.get().isMuted() ? "UNMUTE" : "MUTE");
    }

    private void renderTranscript() {
        StringBuilder sb = new StringBuilder();
        int from = Math.max(0, lines.size() - 40);
        for (int i = from; i < lines.size(); i++) sb.append(lines.get(i)).append("\n\n");
        if (!liveUser.isEmpty()) sb.append("YOU: ").append(liveUser).append("\n\n");
        if (!liveAsst.isEmpty()) sb.append(Prefs.assistantName(this).toUpperCase()).append(": ").append(liveAsst);
        transcript.setText(sb.toString().trim());
        scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
    }

    // ------------------------------------------------------------------ Bus.Ui

    @Override
    public void onState(final String state) {
        ui.post(() -> {
            hud.setState(state);
            updateMic();
        });
    }

    @Override
    public void onUserText(final String text, final boolean finished) {
        ui.post(() -> {
            if (finished) {
                if (!text.isEmpty()) lines.add("YOU: " + text);
                liveUser = "";
            } else {
                liveUser = text;
            }
            renderTranscript();
        });
    }

    @Override
    public void onAssistantText(final String text, final boolean finished) {
        ui.post(() -> {
            if (finished) {
                if (!text.isEmpty()) lines.add(Prefs.assistantName(this).toUpperCase() + ": " + text);
                liveAsst = "";
            } else {
                liveAsst = text;
            }
            renderTranscript();
        });
    }

    @Override
    public void onLevels(float micLevel, float speakerLevel) {
        hud.setLevels(micLevel, speakerLevel);
    }

    @Override
    public void onLog(final String line) {
        ui.post(() -> {
            logBuf.append(line).append('\n');
            if (logBuf.length() > 600) logBuf.delete(0, logBuf.length() - 600);
            logView.setText(logBuf.toString().trim());
        });
    }

    @Override
    public void onImage(final Bitmap bmp, final String label) {
        ui.post(() -> {
            if (bmp == null) {
                preview.setVisibility(View.GONE);
                previewLabel.setVisibility(View.GONE);
            } else {
                preview.setImageBitmap(bmp);
                preview.setVisibility(View.VISIBLE);
                previewLabel.setText(label + "  (tap to hide)");
                previewLabel.setVisibility(View.VISIBLE);
            }
        });
    }

    @Override
    public boolean confirm(final String message) {
        final CountDownLatch latch = new CountDownLatch(1);
        final boolean[] answer = new boolean[1];
        final AlertDialog[] dlg = new AlertDialog[1];
        ui.post(() -> {
            try {
                dlg[0] = new AlertDialog.Builder(MainActivity.this)
                        .setTitle(Prefs.assistantName(MainActivity.this) + " asks permission")
                        .setMessage(message)
                        .setCancelable(false)
                        .setPositiveButton("Allow", (d, w) -> {
                            answer[0] = true;
                            latch.countDown();
                        })
                        .setNegativeButton("Deny", (d, w) -> latch.countDown())
                        .show();
            } catch (Exception e) {
                latch.countDown();
            }
        });
        try {
            if (!latch.await(45, TimeUnit.SECONDS)) {
                ui.post(() -> {
                    if (dlg[0] != null && dlg[0].isShowing()) dlg[0].dismiss();
                });
                return false;
            }
        } catch (InterruptedException e) {
            return false;
        }
        return answer[0];
    }
}
