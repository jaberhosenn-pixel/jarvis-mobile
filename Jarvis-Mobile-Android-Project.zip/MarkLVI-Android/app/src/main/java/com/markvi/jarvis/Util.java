package com.markvi.jarvis;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.provider.ContactsContract;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Locale;

/** Small shared helpers: notifications, launching activities, contacts, undo. */
public final class Util {
    private Util() {}

    public static final String CHANNEL = "jarvis_main";
    public static final String CHANNEL_ALERT = "jarvis_alert";

    public static void ensureChannels(Context c) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Jarvis running", NotificationManager.IMPORTANCE_LOW));
        NotificationChannel a = new NotificationChannel(CHANNEL_ALERT, "Reminders and alerts", NotificationManager.IMPORTANCE_HIGH);
        nm.createNotificationChannel(a);
    }

    public static void notifyAlert(Context c, int id, String title, String text) {
        ensureChannels(c);
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(c, CHANNEL_ALERT) : new Notification.Builder(c);
        b.setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setAutoCancel(true);
        try {
            nm.notify(id, b.build());
        } catch (Exception ignored) {
        }
    }

    /** Starts an activity from anywhere (service, receiver). */
    public static void launch(Context c, Intent i) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        c.startActivity(i);
    }

    // ------------------------------------------------------------------ contacts

    /** Finds contacts whose name contains the query. Returns [{name, number}]. */
    public static JSONArray findContacts(Context c, String query) {
        JSONArray out = new JSONArray();
        if (query == null || query.trim().isEmpty()) return out;
        ContentResolver cr = c.getContentResolver();
        String q = query.trim();
        try (Cursor cur = cr.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                new String[]{ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                        ContactsContract.CommonDataKinds.Phone.NUMBER},
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
                new String[]{"%" + q + "%"}, null)) {
            if (cur != null) {
                while (cur.moveToNext() && out.length() < 8) {
                    out.put(J.obj("name", cur.getString(0), "number", cur.getString(1)));
                }
            }
        }
        return out;
    }

    public static boolean looksLikeNumber(String s) {
        if (s == null) return false;
        String t = s.replaceAll("[\\s\\-()]", "");
        return t.matches("\\+?\\d{5,}");
    }

    /** Resolves a name or number to a phone number, or null. */
    public static String resolveNumber(Context c, String who) {
        if (who == null) return null;
        if (looksLikeNumber(who)) return who.replaceAll("[\\s\\-()]", "");
        JSONArray a = findContacts(c, who);
        if (a.length() == 0) return null;
        // prefer an exact name match
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o != null && o.optString("name").equalsIgnoreCase(who.trim())) {
                return o.optString("number").replaceAll("[\\s\\-()]", "");
            }
        }
        JSONObject o = a.optJSONObject(0);
        return o == null ? null : o.optString("number").replaceAll("[\\s\\-()]", "");
    }

    public static String digitsOnly(String number) {
        return number == null ? "" : number.replaceAll("[^0-9]", "");
    }

    // ------------------------------------------------------------------ undo

    private static final Deque<Object[]> UNDO = new ArrayDeque<>();

    public static synchronized void pushUndo(String description, Runnable revert) {
        UNDO.push(new Object[]{description, revert});
        while (UNDO.size() > 20) UNDO.removeLast();
    }

    public static synchronized String undoLast() {
        if (UNDO.isEmpty()) return null;
        Object[] e = UNDO.pop();
        try {
            ((Runnable) e[1]).run();
            return (String) e[0];
        } catch (Exception ex) {
            return "failed to undo " + e[0] + ": " + ex.getMessage();
        }
    }

    public static synchronized JSONArray undoList() {
        JSONArray a = new JSONArray();
        for (Object[] e : UNDO) a.put(e[0]);
        return a;
    }

    public static String lower(String s) {
        return s == null ? "" : s.toLowerCase(Locale.ROOT);
    }

    public static Uri uri(String s) {
        return Uri.parse(s);
    }
}
