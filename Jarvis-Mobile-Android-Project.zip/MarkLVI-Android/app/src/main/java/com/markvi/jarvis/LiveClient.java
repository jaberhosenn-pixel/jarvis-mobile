package com.markvi.jarvis;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaRecorder;
import android.media.audiofx.AcousticEchoCanceler;
import android.media.audiofx.NoiseSuppressor;
import android.os.SystemClock;
import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;
import okio.ByteString;

/**
 * Gemini Live over a WebSocket: streams the microphone up, plays the voice that comes back, and
 * hands tool calls to the owner. Mobile twin of the Live session in main.py.
 */
public class LiveClient {

    public interface Listener {
        void onReady();
        void onUserText(String text, boolean finished);
        void onAssistantText(String text, boolean finished);
        void onToolCall(String id, String name, JSONObject args);
        void onClosed(String reason, boolean fatal);
    }

    private static final int SEND_RATE = 16000;
    private static final int RECV_RATE = 24000;

    private final Context ctx;
    private final Listener listener;
    private final OkHttpClient client = new OkHttpClient.Builder()
            .pingInterval(20, TimeUnit.SECONDS)
            .readTimeout(0, TimeUnit.MILLISECONDS)
            .connectTimeout(15, TimeUnit.SECONDS)
            .build();

    private WebSocket ws;
    private volatile boolean active;
    private volatile boolean ready;
    private volatile boolean muted;
    private volatile boolean userStopped;

    // connection plans: model + whether to use the minimal setup
    private final List<String[]> plans = new ArrayList<>();
    private int planIndex;
    private int socketGeneration;

    // audio
    private AudioRecord rec;
    private Thread micThread;
    private AudioTrack track;
    private Thread playThread;
    private final LinkedBlockingQueue<byte[]> playQueue = new LinkedBlockingQueue<>();
    private volatile long speakingUntil;
    private volatile float micLevel;
    private volatile float outLevel;
    private AcousticEchoCanceler aec;
    private NoiseSuppressor ns;

    // transcripts
    private final StringBuilder userBuf = new StringBuilder();
    private final StringBuilder asstBuf = new StringBuilder();

    public LiveClient(Context ctx, Listener l) {
        this.ctx = ctx.getApplicationContext();
        this.listener = l;
    }

    public boolean isReady() {
        return ready;
    }

    public void setMuted(boolean m) {
        muted = m;
    }

    public boolean isMuted() {
        return muted;
    }

    public boolean isSpeaking() {
        return SystemClock.elapsedRealtime() < speakingUntil + 300;
    }

    // ------------------------------------------------------------------ connection

    public synchronized void start() {
        if (active) return;
        active = true;
        userStopped = false;
        ready = false;
        plans.clear();
        String chosen = Prefs.model(ctx);
        List<String> models = new ArrayList<>();
        if (!chosen.isEmpty()) {
            models.add(chosen.startsWith("models/") ? chosen : "models/" + chosen);
        }
        for (String m : Prefs.MODELS) if (!models.contains(m)) models.add(m);
        for (String m : models) {
            plans.add(new String[]{m, "full"});
            plans.add(new String[]{m, "minimal"});
        }
        planIndex = 0;
        Bus.state("CONNECTING");
        openSocket();
    }

    private void openSocket() {
        String key = Prefs.apiKey(ctx);
        if (key.isEmpty()) {
            active = false;
            Bus.state("ERROR");
            listener.onClosed("No Gemini API key. Open Settings and paste one.", true);
            return;
        }
        final int gen = ++socketGeneration;
        String url = "wss://generativelanguage.googleapis.com/ws/"
                + "google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=" + key;
        Request req = new Request.Builder().url(url).build();
        ws = client.newWebSocket(req, new WebSocketListener() {
            @Override
            public void onOpen(WebSocket webSocket, Response response) {
                if (gen != socketGeneration) return;
                try {
                    String[] plan = plans.get(planIndex);
                    JSONObject setup = buildSetup(plan[0], plan[1].equals("minimal"));
                    webSocket.send(J.obj("setup", setup).toString());
                    Bus.log("Connecting to " + plan[0] + " (" + plan[1] + ")");
                } catch (Exception e) {
                    Bus.log("Setup error: " + e.getMessage());
                }
            }

            @Override
            public void onMessage(WebSocket webSocket, String text) {
                if (gen != socketGeneration) return;
                handle(text);
            }

            @Override
            public void onMessage(WebSocket webSocket, ByteString bytes) {
                if (gen != socketGeneration) return;
                handle(bytes.utf8());
            }

            @Override
            public void onClosing(WebSocket webSocket, int code, String reason) {
                webSocket.close(1000, null);
            }

            @Override
            public void onClosed(WebSocket webSocket, int code, String reason) {
                if (gen != socketGeneration) return;
                socketEnded(code + " " + reason);
            }

            @Override
            public void onFailure(WebSocket webSocket, Throwable t, Response response) {
                if (gen != socketGeneration) return;
                String msg = t.getClass().getSimpleName() + ": " + t.getMessage();
                if (response != null) msg += " (HTTP " + response.code() + ")";
                socketEnded(msg);
            }
        });
    }

    private void socketEnded(String why) {
        if (!active) return;
        stopAudio();
        if (!ready) {
            // never got through setup: try the next plan, unless the key itself is refused
            boolean keyProblem = why.contains("HTTP 400") || why.contains("HTTP 401") || why.contains("HTTP 403")
                    || why.toLowerCase().contains("api key") || why.toLowerCase().contains("permission");
            planIndex++;
            if (!keyProblem && planIndex < plans.size() && !userStopped) {
                Bus.log("Rejected (" + GeminiRest.abbreviate(why, 140) + "). Trying next option...");
                openSocket();
                return;
            }
            active = false;
            Bus.state("ERROR");
            listener.onClosed(keyProblem
                    ? "The Gemini API key was refused. Check it in Settings. (" + GeminiRest.abbreviate(why, 120) + ")"
                    : "Could not start a live session: " + GeminiRest.abbreviate(why, 160), true);
            return;
        }
        active = false;
        ready = false;
        Bus.state("IDLE");
        listener.onClosed(why, false);
    }

    public synchronized void stop() {
        userStopped = true;
        active = false;
        ready = false;
        socketGeneration++;
        stopAudio();
        if (ws != null) {
            try {
                ws.close(1000, "bye");
            } catch (Exception ignored) {
            }
            ws = null;
        }
        Bus.state("IDLE");
    }

    private JSONObject buildSetup(String model, boolean minimal) {
        JSONObject gen = J.obj(
                "responseModalities", J.arr("AUDIO"),
                "speechConfig", J.obj("voiceConfig", J.obj("prebuiltVoiceConfig",
                        J.obj("voiceName", Prefs.voice(ctx)))));
        if (!minimal && Prefs.thinking(ctx)) {
            J.put(gen, "thinkingConfig", J.obj("thinkingBudget", -1));
        }
        JSONObject setup = J.obj(
                "model", model,
                "generationConfig", gen,
                "systemInstruction", J.obj("parts", J.arr(J.obj("text", Tools.systemPrompt(ctx)))),
                "tools", J.arr(J.obj("functionDeclarations", Tools.declarations())));
        if (!minimal) {
            J.put(setup, "inputAudioTranscription", new JSONObject());
            J.put(setup, "outputAudioTranscription", new JSONObject());
            J.put(setup, "contextWindowCompression", J.obj("slidingWindow", new JSONObject()));
        }
        return setup;
    }

    // ------------------------------------------------------------------ sending

    private void send(JSONObject o) {
        WebSocket w = ws;
        if (w != null && ready) w.send(o.toString());
    }

    public void sendText(String text) {
        send(J.obj("realtimeInput", J.obj("text", text)));
    }

    public void sendImage(byte[] jpeg) {
        send(J.obj("realtimeInput", J.obj("video", J.obj(
                "data", Base64.encodeToString(jpeg, Base64.NO_WRAP),
                "mimeType", "image/jpeg"))));
    }

    public void sendToolResponse(String id, String name, JSONObject response) {
        JSONObject fr = J.obj("id", id, "name", name, "response", response);
        send(J.obj("toolResponse", J.obj("functionResponses", J.arr(fr))));
    }

    // ------------------------------------------------------------------ receiving

    private void handle(String text) {
        JSONObject o = J.parse(text);

        if (o.has("setupComplete")) {
            ready = true;
            Bus.log("Live session ready");
            startPlayback();
            startMic();
            Bus.state("LISTENING");
            listener.onReady();
            return;
        }

        JSONObject sc = o.optJSONObject("serverContent");
        if (sc != null) {
            if (sc.optBoolean("interrupted")) {
                flushPlayback();
                finishAssistant();
            }
            JSONObject mt = sc.optJSONObject("modelTurn");
            if (mt != null) {
                JSONArray parts = mt.optJSONArray("parts");
                if (parts != null) {
                    for (int i = 0; i < parts.length(); i++) {
                        JSONObject p = parts.optJSONObject(i);
                        if (p == null) continue;
                        JSONObject inl = p.optJSONObject("inlineData");
                        if (inl == null) inl = p.optJSONObject("inline_data");
                        if (inl != null) {
                            String b64 = inl.optString("data", "");
                            if (!b64.isEmpty()) {
                                byte[] pcm = Base64.decode(b64, Base64.DEFAULT);
                                enqueueAudio(pcm);
                            }
                        }
                    }
                }
            }
            JSONObject it = sc.optJSONObject("inputTranscription");
            if (it != null) {
                String t = it.optString("text", "");
                if (!t.isEmpty()) {
                    if (userBuf.length() == 0) finishAssistant();
                    userBuf.append(t);
                    listener.onUserText(userBuf.toString(), false);
                }
            }
            JSONObject ot = sc.optJSONObject("outputTranscription");
            if (ot != null) {
                String t = ot.optString("text", "");
                if (!t.isEmpty()) {
                    finishUser();
                    asstBuf.append(t);
                    listener.onAssistantText(asstBuf.toString(), false);
                }
            }
            if (sc.optBoolean("turnComplete") || sc.optBoolean("generationComplete")) {
                finishUser();
                finishAssistant();
                Bus.state("LISTENING");
            }
        }

        JSONObject tc = o.optJSONObject("toolCall");
        if (tc != null) {
            JSONArray calls = tc.optJSONArray("functionCalls");
            if (calls != null) {
                Bus.state("THINKING");
                for (int i = 0; i < calls.length(); i++) {
                    JSONObject c = calls.optJSONObject(i);
                    if (c == null) continue;
                    JSONObject args = c.optJSONObject("args");
                    listener.onToolCall(c.optString("id"), c.optString("name"), args == null ? new JSONObject() : args);
                }
            }
        }
    }

    private void finishUser() {
        if (userBuf.length() > 0) {
            listener.onUserText(userBuf.toString().trim(), true);
            userBuf.setLength(0);
        }
    }

    private void finishAssistant() {
        if (asstBuf.length() > 0) {
            listener.onAssistantText(asstBuf.toString().trim(), true);
            asstBuf.setLength(0);
        }
    }

    // ------------------------------------------------------------------ audio out

    private void startPlayback() {
        try {
            int min = AudioTrack.getMinBufferSize(RECV_RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT);
            track = new AudioTrack.Builder()
                    .setAudioAttributes(new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build())
                    .setAudioFormat(new AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(RECV_RATE)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build())
                    .setBufferSizeInBytes(Math.max(min * 2, 48000))
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build();
            track.play();
        } catch (Exception e) {
            Bus.log("Speaker error: " + e.getMessage());
            return;
        }
        playQueue.clear();
        final AudioTrack t = track;
        playThread = new Thread(() -> {
            while (active && t == track) {
                try {
                    byte[] chunk = playQueue.poll(200, TimeUnit.MILLISECONDS);
                    if (chunk == null) {
                        outLevel *= 0.8f;
                        continue;
                    }
                    outLevel = level(chunk);
                    t.write(chunk, 0, chunk.length);
                } catch (InterruptedException ie) {
                    return;
                } catch (Exception e) {
                    return;
                }
            }
        }, "jarvis-play");
        playThread.setDaemon(true);
        playThread.start();
    }

    private void enqueueAudio(byte[] pcm) {
        if (pcm.length == 0) return;
        long now = SystemClock.elapsedRealtime();
        long dur = (long) pcm.length / 2L * 1000L / RECV_RATE;
        speakingUntil = Math.max(now, speakingUntil) + dur;
        Bus.state("SPEAKING");
        playQueue.offer(pcm);
    }

    private void flushPlayback() {
        playQueue.clear();
        speakingUntil = 0;
        outLevel = 0;
        AudioTrack t = track;
        if (t != null) {
            try {
                t.pause();
                t.flush();
                t.play();
            } catch (Exception ignored) {
            }
        }
    }

    private static float level(byte[] pcm) {
        long sum = 0;
        int n = pcm.length / 2;
        if (n == 0) return 0f;
        for (int i = 0; i < n; i++) {
            int s = (short) ((pcm[2 * i] & 0xff) | (pcm[2 * i + 1] << 8));
            sum += (long) s * s;
        }
        double rms = Math.sqrt(sum / (double) n) / 32768.0;
        return (float) Math.min(1.0, rms * 4.0);
    }

    // ------------------------------------------------------------------ audio in

    private void startMic() {
        try {
            int min = AudioRecord.getMinBufferSize(SEND_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
            int buf = Math.max(min, 8192) * 2;
            rec = new AudioRecord(MediaRecorder.AudioSource.VOICE_COMMUNICATION, SEND_RATE,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, buf);
            if (rec.getState() != AudioRecord.STATE_INITIALIZED) {
                rec.release();
                rec = new AudioRecord(MediaRecorder.AudioSource.MIC, SEND_RATE,
                        AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, buf);
            }
            if (rec.getState() != AudioRecord.STATE_INITIALIZED) {
                Bus.log("Microphone could not start (permission?)");
                return;
            }
            try {
                if (AcousticEchoCanceler.isAvailable()) {
                    aec = AcousticEchoCanceler.create(rec.getAudioSessionId());
                    if (aec != null) aec.setEnabled(true);
                }
                if (NoiseSuppressor.isAvailable()) {
                    ns = NoiseSuppressor.create(rec.getAudioSessionId());
                    if (ns != null) ns.setEnabled(true);
                }
            } catch (Exception ignored) {
            }
            rec.startRecording();
        } catch (SecurityException se) {
            Bus.log("Microphone permission missing");
            return;
        } catch (Exception e) {
            Bus.log("Microphone error: " + e.getMessage());
            return;
        }

        final AudioRecord r = rec;
        micThread = new Thread(() -> {
            short[] frame = new short[512];
            byte[] bytes = new byte[frame.length * 2];
            while (active && r == rec) {
                int n = r.read(frame, 0, frame.length);
                if (n <= 0) continue;
                long sum = 0;
                for (int i = 0; i < n; i++) {
                    sum += (long) frame[i] * frame[i];
                    bytes[2 * i] = (byte) (frame[i] & 0xff);
                    bytes[2 * i + 1] = (byte) ((frame[i] >> 8) & 0xff);
                }
                double rms = Math.sqrt(sum / (double) n) / 32768.0;
                micLevel = (float) Math.min(1.0, rms * 6.0);
                Bus.Ui ui = Bus.ui;
                if (ui != null) ui.onLevels(micLevel, outLevel);

                boolean gate = muted || (!Prefs.allowInterrupt(ctx) && isSpeaking());
                if (!ready || gate) continue;
                byte[] copy = new byte[n * 2];
                System.arraycopy(bytes, 0, copy, 0, n * 2);
                WebSocket w = ws;
                if (w != null) {
                    w.send(J.obj("realtimeInput", J.obj("audio", J.obj(
                            "data", Base64.encodeToString(copy, Base64.NO_WRAP),
                            "mimeType", "audio/pcm;rate=" + SEND_RATE))).toString());
                }
            }
        }, "jarvis-mic");
        micThread.setDaemon(true);
        micThread.start();
    }

    private void stopAudio() {
        AudioRecord r = rec;
        rec = null;
        if (r != null) {
            try {
                r.stop();
            } catch (Exception ignored) {
            }
            r.release();
        }
        try {
            if (aec != null) aec.release();
            if (ns != null) ns.release();
        } catch (Exception ignored) {
        }
        aec = null;
        ns = null;
        AudioTrack t = track;
        track = null;
        if (t != null) {
            try {
                t.stop();
            } catch (Exception ignored) {
            }
            t.release();
        }
        playQueue.clear();
        speakingUntil = 0;
        micLevel = 0;
        outLevel = 0;
        Bus.Ui ui = Bus.ui;
        if (ui != null) ui.onLevels(0, 0);
    }
}
