package com.markvi.jarvis;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import org.json.JSONArray;

/** Once a day: checks every monitored topic and notifies when something new happened. */
public class MonitorReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(final Context c, Intent i) {
        final PendingResult pr = goAsync();
        new Thread(() -> {
            try {
                JSONArray topics = ToolsCore.monitorTopics(c);
                for (int k = 0; k < topics.length() && k < 8; k++) {
                    String t = topics.optString(k);
                    try {
                        String r = GeminiRest.generate(c, "Is there a genuinely new development in the last 24 hours on: " + t
                                + "? If nothing notable, answer exactly NONE. Otherwise answer in two short sentences.", true, null, null);
                        if (!r.trim().toUpperCase().startsWith("NONE")) {
                            Util.notifyAlert(c, 5000 + k, "Update: " + t, r);
                            JarvisService s = JarvisService.get();
                            if (s != null && s.isLive()) s.alert("New development on " + t + ": " + r);
                        }
                    } catch (Exception ignored) {
                    }
                }
            } finally {
                pr.finish();
            }
        }).start();
    }
}
