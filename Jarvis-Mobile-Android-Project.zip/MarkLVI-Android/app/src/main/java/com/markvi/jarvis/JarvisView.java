package com.markvi.jarvis;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.View;

/**
 * The HUD face: a software-drawn holographic orb that reacts to the voice. Mobile replacement for
 * the PyQt avatar in core/avatar.py (it is drawn with plain Canvas calls, no GPU libraries).
 */
public class JarvisView extends View {

    private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bar = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint grid = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();

    private volatile String state = "IDLE";
    private volatile float micIn;
    private volatile float spkIn;
    private float mic;
    private float spk;
    private long t0 = System.nanoTime();

    public JarvisView(Context c) {
        super(c);
        init();
    }

    public JarvisView(Context c, AttributeSet a) {
        super(c, a);
        init();
    }

    private void init() {
        ring.setStyle(Paint.Style.STROKE);
        bar.setStyle(Paint.Style.STROKE);
        bar.setStrokeCap(Paint.Cap.ROUND);
        grid.setStyle(Paint.Style.STROKE);
        grid.setStrokeWidth(1f);
        text.setTextAlign(Paint.Align.CENTER);
        text.setLetterSpacing(0.3f);
        setBackgroundColor(Color.parseColor("#03080F"));
    }

    public void setState(String s) {
        state = s == null ? "IDLE" : s;
    }

    public void setLevels(float m, float s) {
        micIn = m;
        spkIn = s;
    }

    private int accent() {
        switch (state) {
            case "CONNECTING": return Color.parseColor("#FFB300");
            case "THINKING": return Color.parseColor("#B388FF");
            case "SPEAKING": return Color.parseColor("#40C4FF");
            case "LISTENING": return Color.parseColor("#00E5FF");
            case "ERROR": return Color.parseColor("#FF5252");
            default: return Color.parseColor("#26788A");
        }
    }

    private static int alpha(int color, float a) {
        int al = Math.max(0, Math.min(255, Math.round(a * 255)));
        return Color.argb(al, Color.red(color), Color.green(color), Color.blue(color));
    }

    @Override
    protected void onDraw(Canvas cv) {
        super.onDraw(cv);
        float w = getWidth();
        float h = getHeight();
        float t = (System.nanoTime() - t0) / 1e9f;
        int col = accent();

        mic += (micIn - mic) * 0.35f;
        spk += (spkIn - spk) * 0.35f;
        boolean speaking = state.equals("SPEAKING");
        float level = speaking ? spk : (state.equals("LISTENING") ? mic : 0f);
        boolean thinking = state.equals("THINKING") || state.equals("CONNECTING");

        float cx = w / 2f;
        float cy = h * 0.36f;
        float base = Math.min(w, h) * 0.20f;
        float pulse = base * (1f + 0.18f * level + 0.02f * (float) Math.sin(t * 2f));

        // faint grid
        grid.setColor(alpha(col, 0.05f));
        float step = Math.max(40f, w / 9f);
        for (float x = 0; x < w; x += step) cv.drawLine(x, 0, x, h, grid);
        for (float y = 0; y < h; y += step) cv.drawLine(0, y, w, y, grid);

        // glow
        glow.setShader(new RadialGradient(cx, cy, pulse * 2.3f,
                new int[]{alpha(col, 0.30f + 0.3f * level), alpha(col, 0.06f), alpha(col, 0f)},
                new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
        cv.drawCircle(cx, cy, pulse * 2.3f, glow);

        // core
        glow.setShader(new RadialGradient(cx, cy - pulse * 0.2f, pulse,
                new int[]{alpha(Color.WHITE, 0.85f), alpha(col, 0.85f), alpha(col, 0.15f)},
                new float[]{0f, 0.45f, 1f}, Shader.TileMode.CLAMP));
        cv.drawCircle(cx, cy, pulse * 0.62f, glow);

        // rotating arc rings
        float spin = thinking ? 140f : 40f;
        for (int i = 0; i < 3; i++) {
            float r = pulse * (1.0f + 0.28f * i);
            ring.setStrokeWidth(3f - i * 0.6f);
            ring.setColor(alpha(col, 0.85f - 0.2f * i));
            rect.set(cx - r, cy - r, cx + r, cy + r);
            float dir = i % 2 == 0 ? 1f : -1f;
            float start = dir * (t * spin * (1f + 0.4f * i));
            for (int k = 0; k < 3; k++) {
                cv.drawArc(rect, start + k * 120f, 70f - i * 12f, false, ring);
            }
        }

        // voice bars around the orb
        int n = 72;
        float inner = pulse * 1.95f;
        bar.setStrokeWidth(Math.max(3f, w * 0.006f));
        bar.setColor(alpha(col, 0.9f));
        for (int i = 0; i < n; i++) {
            double ang = i * (2 * Math.PI / n) + t * 0.1;
            float wob = 0.5f + 0.5f * (float) Math.sin(t * 5f + i * 0.9f) * (float) Math.cos(t * 3.1f + i * 0.37f);
            float len = base * (0.06f + (level * 0.55f) * wob + (thinking ? 0.05f * wob : 0f));
            float x1 = cx + (float) Math.cos(ang) * inner;
            float y1 = cy + (float) Math.sin(ang) * inner;
            float x2 = cx + (float) Math.cos(ang) * (inner + len);
            float y2 = cy + (float) Math.sin(ang) * (inner + len);
            cv.drawLine(x1, y1, x2, y2, bar);
        }

        // label
        text.setColor(alpha(col, 0.9f));
        text.setTextSize(Math.max(28f, w * 0.036f));
        String label;
        switch (state) {
            case "CONNECTING": label = "CONNECTING"; break;
            case "LISTENING": label = "LISTENING"; break;
            case "THINKING": label = "WORKING"; break;
            case "SPEAKING": label = "SPEAKING"; break;
            case "ERROR": label = "OFFLINE"; break;
            default: label = "STANDBY"; break;
        }
        cv.drawText(label, cx, cy + inner + base * 0.9f, text);

        postInvalidateOnAnimation();
    }
}
