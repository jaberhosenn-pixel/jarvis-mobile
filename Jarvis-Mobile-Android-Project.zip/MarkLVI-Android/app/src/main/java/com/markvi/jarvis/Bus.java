package com.markvi.jarvis;

import android.graphics.Bitmap;

/** Wires the background service to whatever screen is currently showing. */
public final class Bus {
    private Bus() {}

    public interface Ui {
        void onState(String state);              // IDLE | CONNECTING | LISTENING | THINKING | SPEAKING | ERROR
        void onUserText(String text, boolean finished);
        void onAssistantText(String text, boolean finished);
        void onLevels(float micLevel, float speakerLevel);
        void onLog(String line);
        void onImage(Bitmap bmp, String label);
        /** Blocks the calling (worker) thread until the user answers. */
        boolean confirm(String message);
    }

    public static volatile Ui ui;
    public static volatile String lastState = "IDLE";

    public static void state(String s) {
        lastState = s;
        Ui u = ui;
        if (u != null) u.onState(s);
    }

    public static void log(String s) {
        Ui u = ui;
        if (u != null) u.onLog(s);
    }

    /** Ask the person to approve a sensitive action. False when no screen is up to ask on. */
    public static boolean confirm(String message) {
        Ui u = ui;
        if (u == null) return false;
        try {
            return u.confirm(message);
        } catch (Exception e) {
            return false;
        }
    }
}
